// Обертка для fetch через прокси
function proxyFetch(url, options) {
  const proxiedUrl = 'https://corsproxy.io/?' + encodeURIComponent(url);
  return fetch(proxiedUrl, options);
}

// Использование в syncToCloud:
function syncToCloud(mode) {
  let apiUrl = "https://script.google.com/macros/s/AKfycbzkrLCTLL0Tcw7hUMmyPoPzepr-lxBA97v8DI6uaD7HgsVNCf8Z9mA27inhEOYuPH5-/exec";
  // ... формируете data, например:
  let data = { action: mode === 'upload' ? 'save' : 'load', /* ваши данные */ };
  proxyFetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
  .then(resp => resp.json())
  .then(resData => {
    // ... ваша обработка результата
    console.log(resData);
  })
  .catch(err => {
    // ... обработка ошибок
    console.error(err);
  });
}